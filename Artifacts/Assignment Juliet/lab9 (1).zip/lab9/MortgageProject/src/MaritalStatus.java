public enum MaritalStatus {
    SINGLE, MARRIED;
}
