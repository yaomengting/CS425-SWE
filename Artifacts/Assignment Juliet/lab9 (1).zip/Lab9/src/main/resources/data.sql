INSERT INTO STUDENT(id, name, major) VALUES (111, 'Meti', 'CS');
INSERT INTO STUDENT(id, name, major) VALUES (112, 'Tedros', 'CS');
INSERT INTO STUDENT(id, name, major) VALUES (113, 'Pascal', 'CS');

create sequence if not exists student start with 114;