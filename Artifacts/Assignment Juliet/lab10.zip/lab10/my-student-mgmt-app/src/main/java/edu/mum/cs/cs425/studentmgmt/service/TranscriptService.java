package edu.mum.cs.cs425.studentmgmt.service;

import edu.mum.cs.cs425.studentmgmt.model.Transcript;

public interface TranscriptService {
    public abstract Transcript createTranscript(Transcript transcript);
}
