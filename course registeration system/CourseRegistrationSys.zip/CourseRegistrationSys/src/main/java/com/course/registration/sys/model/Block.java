package com.course.registration.sys.model;

public enum Block {
    BLOCK_1, BLOCK_2, BLOCK_3, BLOCK_4;
}
