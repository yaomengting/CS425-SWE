package com.course.registration.sys.model;

public enum Status {
    PENDING, APPROVED;
}
